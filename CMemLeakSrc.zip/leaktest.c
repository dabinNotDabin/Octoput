//http://www.experts-exchange.com/Programming/Programming_Languages/C/Q_20440501.html
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "CMemleak.h"

typedef struct {
    char **line_fields;
    int field_count;
    int field_max;  //NEW
} LINE;

void parse_line(const char *line_buffer, LINE *line);
void free_line(LINE *line);

int main(void) {
    LINE *current_line;
    char line_buffer[] = "value1,value2,value3,value4";
    int max_runs = 1000;
    int x;

    // Process each line
    for(x = 0; x < max_runs; x++) {

         // Allocate space for the new line struct
         if( (current_line = (LINE *)calloc(1, sizeof(LINE))) == NULL) {
              fprintf(stderr, "Out of memory!");
              exit(EXIT_FAILURE);
         }

         // Allocate space for the line's fields
         current_line->field_max = 1;  //NEW
         current_line->line_fields = (char **)calloc(current_line->field_max, sizeof(char *)); //NEW
         if(current_line->line_fields == NULL) {
              fprintf(stderr, "Out of memory!");
              exit(EXIT_FAILURE);
         }

         // Parse the current line
         parse_line(line_buffer, current_line);

         // Do stuff with this line... not important

         // Free up this line
         free_line(current_line);
         current_line = NULL;
    }

    return(0);
}

void parse_line(const char *line_buffer, LINE *line) {
    char *tmp_buffer;
    char *token;

    // Create a temp string for strtok to murder
    tmp_buffer = (char *)strdup(line_buffer);

    // Break apart the line...
    token = (char *)strtok(tmp_buffer, ",");
    while(token != NULL) {

         if (line->field_count == line->field_max)  //NEW
         {
             line->field_max += 1;
             line->line_fields = (char**) realloc (line->line_fields, line->field_max * sizeof (char*));
         }

         // Copy the field value over to the member
         line->line_fields[ line->field_count ] = (char *)strdup(token);
         line->field_count++;

         // Get next token
         token = (char *)strtok(NULL, ",");
    }

    free (tmp_buffer); //NEW
}

void free_line(LINE *line) {
    int x;

    // Each line field needs to be freed
    for(x = 0; x < line->field_count; x++) {
         free(line->line_fields[x]);
    }

    free(line->line_fields); //NEW

    // Free up the main struct
    free(line);
}
#if 0
// A minimal Win32 console app

#include <stdio.h>
#include "CMemLeak.h"

#define MAX 10

int main() 
{
    int *ok, *imw, *leak;
	
    ok = (int*) malloc (MAX * sizeof (int));
    imw = (int*) malloc (MAX * sizeof (int));
    leak = (int*) malloc (MAX * sizeof (int));
    XWBReport ("after allocations");
	
    ok = (int*) realloc (ok, MAX * 2 * sizeof (int));
    imw[MAX] = 10;

    printf ("\nFree ok\n");
    free (ok);
	
    printf ("\nFree twice\n");
    free (ok);
	
    printf ("\nFree imw\n");
    free (imw);
	
    return 0;
}
#endif